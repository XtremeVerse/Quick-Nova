/**
 * Velo Native Ad Injector
 * Automatically injects native banner ad with Velo theme styling
 */
(function() {
  'use strict';
  
  // Check if ad already exists to prevent duplicates
  if (document.getElementById('velo-ad-container')) {
    return;
  }

  // Create ad wrapper with Velo theme styling
  const adWrapper = document.createElement('div');
  adWrapper.id = 'velo-ad-container';
  adWrapper.style.cssText = `
    margin: 20px auto;
    max-width: 728px;
    text-align: center;
    padding: 16px;
    background: rgba(0, 240, 255, 0.03);
    border: 1px solid rgba(0, 240, 255, 0.15);
    border-radius: 12px;
    box-shadow: 0 4px 16px rgba(0, 176, 255, 0.08);
    backdrop-filter: blur(10px);
  `;

  // Create the ad container div
  const adContainer = document.createElement('div');
  adContainer.id = 'container-a67ed7f7e1954eccf0770b8d03a14e10';
  
  // Create the script element
  const adScript = document.createElement('script');
  adScript.async = true;
  adScript.setAttribute('data-cfasync', 'false');
  adScript.src = '//pl27781663.revenuecpmgate.com/a67ed7f7e1954eccf0770b8d03a14e10/invoke.js';
  
  // Append elements
  adWrapper.appendChild(adScript);
  adWrapper.appendChild(adContainer);
  
  // Inject ad at bottom of body when DOM is ready
  function injectAd() {
    // Try to find footer or main container, otherwise append to body
    const footer = document.querySelector('footer');
    const main = document.querySelector('main, .container');
    
    if (footer) {
      footer.parentNode.insertBefore(adWrapper, footer);
    } else if (main) {
      main.parentNode.insertBefore(adWrapper, main.nextSibling);
    } else {
      document.body.appendChild(adWrapper);
    }
  }
  
  // Execute when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectAd);
  } else {
    injectAd();
  }
})();
