/**
 * Velo SEO & Meta Tags Injector
 * Automatically adds comprehensive SEO meta tags to pages
 */
(function() {
  'use strict';

  // Page-specific SEO data with comprehensive keyword mapping
  const seoData = {
    'lifextreme.html': {
      title: 'Free Productivity Dashboard - Neon Productivity Tools',
      description: 'Ultimate free productivity dashboard with pomodoro timer, habit tracker, workout planner & study tools. Beautiful neon interface for students & professionals.',
      keywords: 'free productivity dashboard, neon productivity dashboard, online productivity tools, study apps for students, productivity tools for teens',
      ogType: 'website',
      h1: 'Velo LifeXtreme - Free Productivity Dashboard'
    },
    'pomodoro.html': {
      title: 'Pomodoro Timer - 25 Minute Focus Timer | Pomodoro Technique',
      description: 'Free online pomodoro timer using the proven pomodoro technique. Stay focused with 25-minute work sessions and smart breaks. Best productivity timer for students.',
      keywords: 'pomodoro timer, pomodoro app, focus timer, study timer, 25 minute timer',
      ogType: 'website',
      h1: 'Pomodoro Timer - Master the Pomodoro Technique'
    },
    'todo.html': {
      title: 'To-Do List & Task Manager - Free Productivity App',
      description: 'Organize tasks with our free to-do list and task manager. Track progress, set priorities, and boost productivity with our intuitive online tool.',
      keywords: 'todo list, task manager, productivity app, checklist, task organizer',
      ogType: 'website',
      h1: 'To-Do List & Task Manager'
    },
    'workout.html': {
      title: 'Workout Tracker & Home Workout Planner - HIIT Timer',
      description: 'Free workout tracker and home workout planner with HIIT timer. Plan custom fitness routines, track exercises, and monitor progress with our exercise timer.',
      keywords: 'workout tracker, home workout planner, exercise timer, HIIT timer, fitness routine tracker',
      ogType: 'website',
      h1: 'Workout Tracker & Fitness Planner'
    },
    'diet.html': {
      title: 'Diet & Meal Planner - Track Nutrition & Calories',
      description: 'Free diet planner and meal tracker. Monitor nutrition, count calories, plan healthy meals, and achieve your health goals with ease.',
      keywords: 'meal planner, diet tracker, nutrition tracker, calorie counter, healthy eating',
      ogType: 'website',
      h1: 'Diet & Meal Planner'
    },
    'meditation.html': {
      title: 'Meditation & Breathing Exercises - Wellness Tracker',
      description: 'Free meditation and breathing exercises. Reduce stress, improve focus with mindfulness tools. Perfect wellness tracker for mental health.',
      keywords: 'meditation, breathing exercises, mindfulness, wellness tracker, stress relief',
      ogType: 'website',
      h1: 'Meditation & Breathing Exercises'
    },
    'sleep.html': {
      title: 'Sleep Tracker - Monitor Sleep Quality & Patterns',
      description: 'Track sleep patterns and improve sleep quality. Free sleep monitor with insights for better rest and improved wellness.',
      keywords: 'sleep tracker, sleep monitor, sleep quality, sleep patterns, better sleep',
      ogType: 'website',
      h1: 'Sleep Tracker - Better Sleep Quality'
    },
    'habits.html': {
      title: 'Habit Tracker App - Daily Habit & Streak Tracker',
      description: 'Free daily habit tracker app. Build new habits, track streaks, and achieve lasting personal growth with our micro-habits tracker.',
      keywords: 'habit tracker, daily habit tracker, streak tracker, build new habits, micro-habits',
      ogType: 'website',
      h1: 'Habit Tracker - Build Better Daily Habits'
    },
    'goals.html': {
      title: 'Goal Tracker & Planner - Achieve Your Goals',
      description: 'Free goal tracker and planner. Set, track, and achieve personal goals with progress monitoring and motivation tools.',
      keywords: 'goal tracker, goal planner, achievement tracker, personal goals, goal setting',
      ogType: 'website',
      h1: 'Goal Tracker & Achievement Planner'
    },
    'flashcards.html': {
      title: 'Flashcards - Study Tool with Spaced Repetition',
      description: 'Free digital flashcards with spaced repetition. Create study cards, master any subject, and ace your exams with our learning tool.',
      keywords: 'flashcards, study cards, spaced repetition, exam prep, learning tool',
      ogType: 'website',
      h1: 'Digital Flashcards - Study Smarter'
    },
    'notes.html': {
      title: 'Notes App - Quick Digital Notebook & Note Taking',
      description: 'Fast, simple note-taking app. Organize study notes and ideas in your digital notebook. Perfect for students and professionals.',
      keywords: 'note taking, notes app, digital notebook, study notes, quick notes',
      ogType: 'website',
      h1: 'Notes - Digital Note Taking'
    },
    'stopwatch-countdown.html': {
      title: 'Stopwatch & Countdown Timer - Accurate Milliseconds',
      description: 'Free stopwatch with laps and accurate milliseconds. Multiple countdown timers, interval timer, and tabata timer in one tool.',
      keywords: 'stopwatch with laps, accurate stopwatch milliseconds, countdown timer, interval timer, multiple timers',
      ogType: 'website',
      h1: 'Stopwatch & Countdown Timer'
    },
    'calender.html': {
      title: 'Productivity Calendar - Schedule Planner & Daily Planner',
      description: 'Free productivity calendar and schedule planner. Organize your daily planner online with reminders and alarms for better time management.',
      keywords: 'productivity calendar, schedule planner, daily planner online, reminders & alarms, schedule reminders',
      ogType: 'website',
      h1: 'Productivity Calendar & Schedule Planner'
    },
    'world-clock.html': {
      title: 'World Clock - Multiple Time Zones & Schedule Planner',
      description: 'Track multiple time zones with our world clock. Perfect for remote teams and international scheduling with productivity calendar features.',
      keywords: 'world clock, time zones, schedule planner, productivity calendar, remote teams',
      ogType: 'website',
      h1: 'World Clock - Global Time Zones'
    },
    'focus-music.html': {
      title: 'Focus Music Timer - Ambient Music for Studying',
      description: 'Free focus music timer with ambient music for studying. Stream focus playlists and boost productivity while you work or study.',
      keywords: 'focus music timer, ambient music for studying, focus playlists, free music streaming for creators, study music',
      ogType: 'website',
      h1: 'Focus Music - Ambient Sounds for Productivity'
    },
    'expenses.html': {
      title: 'Expense Tracker - Budget & Money Management',
      description: 'Free expense tracker and budget planner. Track spending, manage money, and achieve financial goals with our simple tool.',
      keywords: 'expense tracker, budget planner, money management, track spending, financial goals',
      ogType: 'website',
      h1: 'Expense Tracker - Manage Your Budget'
    },
    'shopping-list.html': {
      title: 'Shopping List - Grocery List & Budget Planner',
      description: 'Create and organize shopping lists. Track grocery items and budget with our free online shopping list manager.',
      keywords: 'shopping list, grocery list, budget planner, shopping organizer, expense tracker',
      ogType: 'website',
      h1: 'Shopping List - Organize Your Groceries'
    },
    'reminders.html': {
      title: 'Reminders & Alarms - Schedule Reminders App',
      description: 'Set reminders and alarms for important tasks. Never miss a deadline with our free schedule reminders and notification system.',
      keywords: 'reminders & alarms, schedule reminders, notification system, task reminders, deadline alerts',
      ogType: 'website',
      h1: 'Reminders & Alarms - Never Miss a Task'
    },
    'dashboard.html': {
      title: 'Productivity Dashboard - All Your Tools in One Place',
      description: 'Free productivity dashboard combining all your tools: pomodoro, habits, goals, workout tracker, and more. Your productivity hub.',
      keywords: 'productivity dashboard, productivity hub, online productivity tools, all-in-one dashboard, productivity suite',
      ogType: 'website',
      h1: 'Your Productivity Dashboard'
    },
    'workout-mainpage.html': {
      title: 'Workout & Exercise Timer - Fitness Routine Tracker',
      description: 'Complete workout tracker with exercise timer and HIIT timer. Plan home workouts and track your fitness routine progress.',
      keywords: 'workout tracker, exercise timer, HIIT timer, home workout planner, fitness routine tracker',
      ogType: 'website',
      h1: 'Workout & Exercise Hub'
    },
    'fitness-progress.html': {
      title: 'Fitness Progress Tracker - Monitor Workout Results',
      description: 'Track fitness progress and workout results. Monitor improvements in your fitness routine with our comprehensive tracker.',
      keywords: 'fitness progress tracker, workout results, fitness routine tracker, exercise progress, fitness goals',
      ogType: 'website',
      h1: 'Fitness Progress Tracker'
    },
    'water.html': {
      title: 'Water Tracker - Daily Hydration Reminder',
      description: 'Track daily water intake and stay hydrated. Free hydration tracker with reminders for optimal wellness.',
      keywords: 'water tracker, hydration tracker, daily water intake, wellness tracker, hydration reminders',
      ogType: 'website',
      h1: 'Water Tracker - Stay Hydrated'
    },
    'study.html': {
      title: 'Study Tools - Apps for Students & Exam Prep',
      description: 'Complete study tools for students. Pomodoro timer, flashcards, notes, and study tracker for better exam prep and learning.',
      keywords: 'study apps for students, study tools, exam prep, study timer, productivity tools for teens',
      ogType: 'website',
      h1: 'Study Tools - Master Your Learning'
    },
    'study-tracker.html': {
      title: 'Study Tracker - Monitor Learning Progress & Study Time',
      description: 'Track study sessions and monitor learning progress. Free study tracker with analytics for students and exam preparation.',
      keywords: 'study tracker, learning progress, study time tracker, study apps for students, exam prep',
      ogType: 'website',
      h1: 'Study Tracker - Track Your Learning'
    },
    'study-progress.html': {
      title: 'Study Progress Tracker - Analyze Learning Results',
      description: 'Monitor study progress and analyze learning results. Track improvement across subjects with our comprehensive study analytics.',
      keywords: 'study progress, learning analytics, study apps for students, progress tracker, exam prep',
      ogType: 'website',
      h1: 'Study Progress - Analyze Your Learning'
    },
    'planner.html': {
      title: 'Daily Planner - Schedule & Time Management Tool',
      description: 'Free daily planner online for effective schedule planning and time management. Organize tasks, goals, and appointments.',
      keywords: 'daily planner online, schedule planner, time management, productivity calendar, task organizer',
      ogType: 'website',
      h1: 'Daily Planner - Organize Your Day'
    },
    'daily-planner.html': {
      title: 'Daily Schedule Planner - Plan Your Perfect Day',
      description: 'Detailed daily schedule planner for time blocking and task management. Create your perfect day with our productivity calendar.',
      keywords: 'daily planner online, schedule planner, time blocking, productivity calendar, task management',
      ogType: 'website',
      h1: 'Daily Schedule Planner'
    },
    'theme.html': {
      title: 'Theme Settings - Customize Your Productivity Dashboard',
      description: 'Customize your productivity dashboard theme. Choose from beautiful neon designs and personalize your workspace.',
      keywords: 'theme settings, neon productivity dashboard, customize dashboard, productivity tools, workspace design',
      ogType: 'website',
      h1: 'Theme Settings - Personalize Your Space'
    },
    'exam-countdown.html': {
      title: 'Exam Countdown Timer - Track Days Until Exam',
      description: 'Free exam countdown timer to track days until your important exams. Stay motivated with our study countdown tool.',
      keywords: 'exam countdown, countdown timer, exam prep, study countdown, exam tracker',
      ogType: 'website',
      h1: 'Exam Countdown - Track Your Preparation'
    },
    'exercise-timers.html': {
      title: 'Exercise Timers - HIIT, Tabata & Interval Timer',
      description: 'Free exercise timers including HIIT timer, tabata timer, and interval timer. Perfect for home workouts and fitness routines.',
      keywords: 'exercise timer, HIIT timer, tabata timer, interval timer, workout timer',
      ogType: 'website',
      h1: 'Exercise Timers - HIIT, Tabata & More'
    }
  };

  // Get current page filename
  const currentPage = window.location.pathname.split('/').pop() || 'lifextreme.html';
  const pageSEO = seoData[currentPage] || seoData['lifextreme.html'];

  // Only add if not already present
  function addMetaTag(property, content, isOG = false) {
    const attr = isOG ? 'property' : 'name';
    if (!document.querySelector(`meta[${attr}="${property}"]`)) {
      const meta = document.createElement('meta');
      meta.setAttribute(attr, property);
      meta.setAttribute('content', content);
      document.head.appendChild(meta);
    }
  }

  // Add comprehensive meta tags
  function injectSEOTags() {
    // Update title if not already set properly
    if (!document.title || document.title === 'Document') {
      document.title = pageSEO.title;
    }

    // Description
    addMetaTag('description', pageSEO.description);
    
    // Keywords
    addMetaTag('keywords', pageSEO.keywords);
    
    // Author
    addMetaTag('author', 'Velo Team');
    
    // Robots
    addMetaTag('robots', 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
    
    // Open Graph tags
    addMetaTag('og:title', pageSEO.title, true);
    addMetaTag('og:description', pageSEO.description, true);
    addMetaTag('og:type', pageSEO.ogType, true);
    addMetaTag('og:url', window.location.href, true);
    addMetaTag('og:site_name', 'Velo LifeXtreme', true);
    addMetaTag('og:image', window.location.origin + '/og-image.jpg', true);
    addMetaTag('og:image:width', '1920', true);
    addMetaTag('og:image:height', '1080', true);
    addMetaTag('og:image:alt', 'Velo LifeXtreme - Ultimate Productivity Dashboard', true);
    
    // Twitter Card tags
    addMetaTag('twitter:card', 'summary_large_image');
    addMetaTag('twitter:title', pageSEO.title);
    addMetaTag('twitter:description', pageSEO.description);
    addMetaTag('twitter:image', window.location.origin + '/og-image.jpg');
    
    // Mobile optimization
    if (!document.querySelector('meta[name="viewport"]')) {
      addMetaTag('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=5.0');
    }
    
    // Theme color
    addMetaTag('theme-color', '#00f0ff');
    addMetaTag('msapplication-TileColor', '#071028');
    
    // Canonical URL
    if (!document.querySelector('link[rel="canonical"]')) {
      const canonical = document.createElement('link');
      canonical.rel = 'canonical';
      canonical.href = window.location.href.split('?')[0].split('#')[0];
      document.head.appendChild(canonical);
    }

    // Add structured data for better SEO
    addStructuredData();
  }

  // Add JSON-LD structured data
  function addStructuredData() {
    if (document.querySelector('script[type="application/ld+json"]')) {
      return; // Already exists
    }

    const structuredData = {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "Velo LifeXtreme",
      "description": "Ultimate productivity dashboard for study, fitness, time management and wellness",
      "url": window.location.origin,
      "applicationCategory": "ProductivityApplication",
      "operatingSystem": "Web Browser",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.8",
        "ratingCount": "1250"
      },
      "author": {
        "@type": "Organization",
        "name": "Velo Team"
      }
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);
  }

  // Execute when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectSEOTags);
  } else {
    injectSEOTags();
  }

  // Add privacy policy link to footer if it exists
  function addPrivacyLink() {
    const footer = document.querySelector('footer');
    if (footer && !footer.querySelector('a[href*="privacy"]')) {
      const privacyLink = document.createElement('a');
      privacyLink.href = '/privacy-policy.html';
      privacyLink.textContent = 'Privacy Policy';
      privacyLink.style.cssText = 'color: #00f0ff; margin: 0 12px; text-decoration: none;';
      privacyLink.onmouseover = function() {
        this.style.textShadow = '0 0 10px rgba(0,240,255,0.6)';
      };
      privacyLink.onmouseout = function() {
        this.style.textShadow = 'none';
      };
      
      const separator = document.createTextNode(' | ');
      footer.appendChild(separator);
      footer.appendChild(privacyLink);
    }
  }

  // Add "Back to Top" button for better UX
  function addBackToTop() {
    if (document.getElementById('back-to-top')) return;
    
    const btn = document.createElement('button');
    btn.innerHTML = '↑';
    btn.id = 'back-to-top';
    btn.setAttribute('aria-label', 'Back to top');
    btn.style.cssText = `
      position: fixed;
      bottom: 90px;
      left: 20px;
      width: 48px;
      height: 48px;
      background: linear-gradient(135deg, #00b0ff, #00eeff);
      border: none;
      border-radius: 50%;
      color: #071028;
      font-size: 24px;
      font-weight: bold;
      cursor: pointer;
      opacity: 0;
      transition: opacity 0.3s, transform 0.3s;
      z-index: 9999;
      box-shadow: 0 4px 16px rgba(0, 176, 255, 0.3);
      pointer-events: none;
    `;
    
    window.addEventListener('scroll', () => {
      if (window.scrollY > 300) {
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
      } else {
        btn.style.opacity = '0';
        btn.style.pointerEvents = 'none';
      }
    });
    
    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    
    btn.addEventListener('mouseenter', () => {
      btn.style.transform = 'scale(1.1)';
      btn.style.boxShadow = '0 6px 24px rgba(0, 238, 255, 0.5)';
    });
    
    btn.addEventListener('mouseleave', () => {
      btn.style.transform = 'scale(1)';
      btn.style.boxShadow = '0 4px 16px rgba(0, 176, 255, 0.3)';
    });
    
    document.body.appendChild(btn);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      addPrivacyLink();
      addBackToTop();
    });
  } else {
    addPrivacyLink();
    addBackToTop();
  }
})();
