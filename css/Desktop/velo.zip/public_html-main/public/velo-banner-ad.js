/**
 * Velo Banner Ad Injector
 * Displays a banner ad (300x250) with Velo theme styling
 */
(function() {
  'use strict';
  
  // Check if banner ad already exists to prevent duplicates
  if (document.getElementById('velo-banner-ad-container')) {
    return;
  }

  // Create banner ad wrapper with Velo theme styling
  const bannerWrapper = document.createElement('div');
  bannerWrapper.id = 'velo-banner-ad-container';
  bannerWrapper.style.cssText = `
    margin: 20px auto;
    max-width: 300px;
    text-align: center;
    padding: 12px;
    background: rgba(0, 240, 255, 0.03);
    border: 1px solid rgba(0, 240, 255, 0.15);
    border-radius: 12px;
    box-shadow: 0 4px 16px rgba(0, 176, 255, 0.08);
    backdrop-filter: blur(10px);
  `;

  // Create the banner ad script
  const bannerScript = document.createElement('script');
  bannerScript.type = 'text/javascript';
  bannerScript.text = `
    atOptions = {
      'key' : '84513f5cfa0dc1d830dcbd10a0a0f857',
      'format' : 'iframe',
      'height' : 250,
      'width' : 300,
      'params' : {}
    };
  `;
  
  // Create the invoke script
  const invokeScript = document.createElement('script');
  invokeScript.type = 'text/javascript';
  invokeScript.src = '//www.highperformanceformat.com/84513f5cfa0dc1d830dcbd10a0a0f857/invoke.js';
  
  // Append elements
  bannerWrapper.appendChild(bannerScript);
  bannerWrapper.appendChild(invokeScript);
  
  // Inject banner ad in sidebar or at the top of main content
  function injectBannerAd() {
    // Try to find sidebar first, then main container
    const sidebar = document.querySelector('.sidebar, aside, [role="complementary"]');
    const main = document.querySelector('main, .main-content, .container');
    
    if (sidebar) {
      sidebar.appendChild(bannerWrapper);
    } else if (main) {
      main.insertBefore(bannerWrapper, main.firstChild);
    } else {
      // Fallback to body
      document.body.insertBefore(bannerWrapper, document.body.firstChild);
    }
  }
  
  // Execute when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectBannerAd);
  } else {
    injectBannerAd();
  }
})();
