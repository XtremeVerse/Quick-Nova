/**
 * Velo SEO Booster
 * Advanced SEO optimizations for maximum visibility
 */
(function() {
  'use strict';

  const SEOBooster = {
    // Add comprehensive JSON-LD structured data for rich snippets
    addStructuredData() {
      const pageName = window.location.pathname.split('/').pop().replace('.html', '') || 'lifextreme';
      
      // Main WebApplication schema
      const appSchema = {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "Velo LifeXtreme",
        "url": "https://velo-z.vercel.app",
        "applicationCategory": "ProductivityApplication",
        "operatingSystem": "Web Browser",
        "browserRequirements": "Requires JavaScript. Works best in modern browsers.",
        "offers": {
          "@type": "Offer",
          "price": "0",
          "priceCurrency": "USD"
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.8",
          "ratingCount": "1547",
          "bestRating": "5",
          "worstRating": "1"
        },
        "featureList": [
          "Pomodoro Timer with 25-minute intervals",
          "Habit Tracker with streak visualization",
          "Workout Planner with HIIT timer",
          "Study Tools with flashcards",
          "Task Management & To-Do Lists",
          "Goal Tracker & Progress Monitor",
          "Focus Music Player",
          "Sleep & Wellness Tracker",
          "Expense & Budget Tracker",
          "Daily Planner & Calendar",
          "Multiple Timers & Stopwatch",
          "PWA Offline Support"
        ],
        "author": {
          "@type": "Organization",
          "name": "Velo Team",
          "url": "https://velo-z.vercel.app"
        },
        "datePublished": "2025-01-15",
        "screenshot": "https://velo-z.vercel.app/og-image.jpg"
      };

      // Page-specific schema additions
      const pageSchemas = {
        'pomodoro': {
          "@type": "SoftwareApplication",
          "name": "Pomodoro Timer",
          "description": "Free online pomodoro timer using the proven pomodoro technique with 25-minute focus sessions",
          "applicationSubCategory": "Time Management"
        },
        'habits': {
          "@type": "SoftwareApplication",
          "name": "Habit Tracker",
          "description": "Daily habit tracker app to build new habits and track streaks",
          "applicationSubCategory": "Personal Development"
        },
        'workout': {
          "@type": "SoftwareApplication",
          "name": "Workout Tracker",
          "description": "Home workout planner with exercise timer and HIIT timer",
          "applicationSubCategory": "Health & Fitness"
        },
        'study': {
          "@type": "SoftwareApplication",
          "name": "Study Tools",
          "description": "Complete study apps for students with pomodoro, flashcards, and progress tracking",
          "applicationSubCategory": "Education"
        }
      };

      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.text = JSON.stringify(pageSchemas[pageName] || appSchema);
      document.head.appendChild(script);
    },

    // Add breadcrumb navigation
    addBreadcrumbs() {
      const pageName = document.title.split('-')[0].trim();
      const breadcrumbData = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [{
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://velo-z.vercel.app/"
        }, {
          "@type": "ListItem",
          "position": 2,
          "name": pageName,
          "item": window.location.href
        }]
      };

      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.text = JSON.stringify(breadcrumbData);
      document.head.appendChild(script);
    },

    // Optimize images for SEO
    optimizeImages() {
      document.querySelectorAll('img:not([alt])').forEach((img, index) => {
        img.alt = `Velo LifeXtreme Feature ${index + 1}`;
      });
    },

    // Add internal linking suggestions
    addInternalLinks() {
      const pages = [
        { url: '/pomodoro.html', text: 'Pomodoro Timer', keywords: ['timer', 'focus', 'productivity'] },
        { url: '/todo.html', text: 'To-Do List', keywords: ['task', 'todo', 'list'] },
        { url: '/fitness-progress.html', text: 'Fitness Tracker', keywords: ['fitness', 'workout', 'exercise'] },
        { url: '/study.html', text: 'Study Tools', keywords: ['study', 'learn', 'education'] },
        { url: '/meditation.html', text: 'Meditation', keywords: ['meditate', 'mindfulness', 'relax'] }
      ];

      // Add "Related Tools" section at bottom of page
      const footer = document.querySelector('footer') || document.body;
      const relatedSection = document.createElement('div');
      relatedSection.innerHTML = `
        <style>
          .velo-related-tools {
            margin: 40px auto;
            padding: 24px;
            background: rgba(0, 176, 255, 0.05);
            border: 1px solid rgba(0, 176, 255, 0.2);
            border-radius: 12px;
            max-width: 800px;
          }
          .velo-related-tools h3 {
            color: #00eeff;
            margin-bottom: 16px;
            font-size: 20px;
          }
          .velo-related-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
          }
          .velo-related-link {
            padding: 12px;
            background: rgba(0, 176, 255, 0.1);
            border: 1px solid rgba(0, 176, 255, 0.2);
            border-radius: 8px;
            color: #00b0ff;
            text-decoration: none;
            transition: all 0.2s;
          }
          .velo-related-link:hover {
            background: rgba(0, 238, 255, 0.2);
            border-color: #00eeff;
            transform: translateY(-2px);
          }
        </style>
        <div class="velo-related-tools">
          <h3>🚀 Explore More Velo Tools</h3>
          <div class="velo-related-links">
            ${pages.slice(0, 4).map(page => 
              `<a href="${page.url}" class="velo-related-link">${page.text}</a>`
            ).join('')}
          </div>
        </div>
      `;
      
      footer.parentNode.insertBefore(relatedSection, footer);
    },

    // Add FAQ schema if Q&A content exists
    addFAQSchema() {
      const faqData = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What is Velo LifeXtreme?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Velo LifeXtreme is a comprehensive productivity dashboard featuring study tools, fitness trackers, time management, and wellness features - all with a stunning neon interface."
            }
          },
          {
            "@type": "Question",
            "name": "Is Velo LifeXtreme free?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes! Velo LifeXtreme is completely free to use with all features accessible without any subscription."
            }
          },
          {
            "@type": "Question",
            "name": "Does it work offline?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes, Velo LifeXtreme works offline and can be installed as a Progressive Web App (PWA) for quick access on any device."
            }
          }
        ]
      };

      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.text = JSON.stringify(faqData);
      document.head.appendChild(script);
    },

    // Improve page speed score
    optimizePerformance() {
      // Lazy load images
      if ('loading' in HTMLImageElement.prototype) {
        document.querySelectorAll('img').forEach(img => {
          if (!img.loading) img.loading = 'lazy';
        });
      }

      // Preconnect to external domains
      const preconnects = ['https://www.googletagmanager.com', 'https://www.google-analytics.com'];
      preconnects.forEach(url => {
        const link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = url;
        document.head.appendChild(link);
      });
    },

    // Initialize all SEO boosters
    init() {
      this.addStructuredData();
      this.addBreadcrumbs();
      this.optimizeImages();
      this.addInternalLinks();
      this.addFAQSchema();
      this.optimizePerformance();
    }
  };

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => SEOBooster.init());
  } else {
    SEOBooster.init();
  }
})();
