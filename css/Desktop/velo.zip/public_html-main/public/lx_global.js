<script>
// --------- Global Progress Resource ---------
(function(){
  const KEY = "lx_meta_progress_v1";

  // Create storage if not exists
  if(!localStorage.getItem(KEY)){
    localStorage.setItem(KEY, JSON.stringify({}));
  }

  // Safe append-only logger
  window.lx_updateProgress = function(module, entry){
    let store = JSON.parse(localStorage.getItem(KEY)) || {};
    if(!store[module]) store[module] = [];
    store[module].push({...entry, ts: Date.now()});
    localStorage.setItem(KEY, JSON.stringify(store));
  };

  // Optional: auto-hook some events
  document.addEventListener("DOMContentLoaded", ()=>{
    // Auto-hook checkboxes (todos)
    document.querySelectorAll("input[type=checkbox]").forEach(cb=>{
      cb.addEventListener("change", ()=>{
        lx_updateProgress("todo", {
          task: cb.name || cb.id || "Untitled Task",
          done: cb.checked
        });
      });
    });

    // Auto-hook buttons with data-duration (pomodoro etc.)
    document.querySelectorAll("[data-duration]").forEach(btn=>{
      btn.addEventListener("click", ()=>{
        lx_updateProgress("pomodoro", {
          label: btn.innerText.trim(),
          duration: parseInt(btn.getAttribute("data-duration"))||25
        });
      });
    });

    // Auto-hook flashcard flips (if using .flashcard class)
    document.querySelectorAll(".flashcard").forEach(fc=>{
      fc.addEventListener("click", ()=>{
        lx_updateProgress("flashcards", {
          deck: fc.dataset.deck || "General",
          action: "flip"
        });
      });
    });
  });
})();
</script>