// =============================================
// Velo Common Library - Universal Utilities
// =============================================

(function() {
  'use strict';

  // Storage API with auto-save
  window.VeloStorage = {
    get(key, defaultValue = null) {
      try {
        const value = localStorage.getItem(key);
        return value ? JSON.parse(value) : defaultValue;
      } catch (e) {
        console.error('Storage get error:', e);
        return defaultValue;
      }
    },

    set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (e) {
        console.error('Storage set error:', e);
        return false;
      }
    },

    remove(key) {
      localStorage.removeItem(key);
    },

    clear() {
      localStorage.clear();
    },

    export(key) {
      const data = this.get(key);
      return JSON.stringify(data, null, 2);
    },

    import(jsonString, key, merge = false) {
      try {
        const data = JSON.parse(jsonString);
        if (merge) {
          const existing = this.get(key, []);
          this.set(key, Array.isArray(existing) ? [...existing, ...data] : data);
        } else {
          this.set(key, data);
        }
        return true;
      } catch (e) {
        console.error('Import error:', e);
        return false;
      }
    },

    // Auto-save wrapper
    autoSave(key, data, debounceMs = 500) {
      clearTimeout(this._autoSaveTimer);
      this._autoSaveTimer = setTimeout(() => {
        this.set(key, data);
      }, debounceMs);
    }
  };

  // UI Utilities
  window.VeloUI = {
    toast(message, type = 'info', duration = 3000) {
      const toast = document.createElement('div');
      toast.className = `velo-toast velo-toast-${type}`;
      toast.textContent = message;
      
      Object.assign(toast.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        background: type === 'success' ? '#00F0FF' : type === 'error' ? '#ff4757' : '#00B0FF',
        color: type === 'success' || type === 'info' ? '#000' : '#fff',
        padding: '12px 24px',
        borderRadius: '8px',
        boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
        zIndex: '10000',
        fontWeight: '600',
        animation: 'veloSlideIn 0.3s ease-out',
        maxWidth: '300px'
      });

      document.body.appendChild(toast);

      setTimeout(() => {
        toast.style.animation = 'veloSlideOut 0.3s ease-out';
        setTimeout(() => toast.remove(), 300);
      }, duration);
    },

    confirm(message, onConfirm, onCancel) {
      if (window.confirm(message)) {
        onConfirm?.();
      } else {
        onCancel?.();
      }
    },

    loading(show = true) {
      let loader = document.getElementById('velo-loader');
      
      if (show && !loader) {
        loader = document.createElement('div');
        loader.id = 'velo-loader';
        loader.innerHTML = '<div class="velo-spinner"></div>';
        
        Object.assign(loader.style, {
          position: 'fixed',
          inset: '0',
          background: 'rgba(0,0,0,0.8)',
          backdropFilter: 'blur(4px)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: '9999'
        });

        document.body.appendChild(loader);
      } else if (!show && loader) {
        loader.remove();
      }
    }
  };

  // Activity History Tracker
  window.VeloHistory = {
    KEY: 'velo_activity_history_v1',

    push(entry) {
      const history = VeloStorage.get(this.KEY, []);
      history.push({
        ...entry,
        timestamp: Date.now(),
        date: new Date().toISOString()
      });
      
      // Keep last 1000 entries
      if (history.length > 1000) {
        history.splice(0, history.length - 1000);
      }
      
      VeloStorage.set(this.KEY, history);
    },

    get(filters = {}) {
      const history = VeloStorage.get(this.KEY, []);
      
      if (!filters.widgetType) return history;
      
      return history.filter(entry => {
        if (filters.widgetType && entry.widgetType !== filters.widgetType) return false;
        if (filters.subtype && entry.subtype !== filters.subtype) return false;
        if (filters.startDate && entry.timestamp < filters.startDate) return false;
        if (filters.endDate && entry.timestamp > filters.endDate) return false;
        return true;
      });
    },

    getStats(widgetType) {
      const entries = this.get({ widgetType });
      return {
        total: entries.length,
        today: entries.filter(e => {
          const today = new Date().toDateString();
          return new Date(e.timestamp).toDateString() === today;
        }).length,
        thisWeek: entries.filter(e => {
          const weekAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
          return e.timestamp > weekAgo;
        }).length
      };
    },

    clear() {
      VeloStorage.remove(this.KEY);
    }
  };

  // Keyboard Shortcuts Manager
  window.VeloKeys = {
    handlers: {},

    init(shortcuts = {}) {
      this.handlers = shortcuts;
      
      document.addEventListener('keydown', (e) => {
        // Ctrl+S or Cmd+S - Save
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
          e.preventDefault();
          this.handlers.save?.();
        }
        
        // Ctrl+E - Export
        if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
          e.preventDefault();
          this.handlers.export?.();
        }
        
        // Ctrl+K - Quick action
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
          e.preventDefault();
          this.handlers.quickAction?.();
        }
        
        // Space - Special action
        if (e.key === ' ' && !['INPUT', 'TEXTAREA'].includes(e.target.tagName)) {
          e.preventDefault();
          this.handlers.space?.();
        }
      });
    }
  };

  // Data Sync Manager
  window.VeloSync = {
    syncAll() {
      const allKeys = Object.keys(localStorage).filter(k => k.startsWith('velo_'));
      const syncData = {};
      
      allKeys.forEach(key => {
        syncData[key] = VeloStorage.get(key);
      });
      
      return syncData;
    },

    exportAll() {
      const data = this.syncAll();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `velo-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      VeloUI.toast('Complete backup exported!', 'success');
    },

    importAll(jsonString) {
      try {
        const data = JSON.parse(jsonString);
        Object.entries(data).forEach(([key, value]) => {
          VeloStorage.set(key, value);
        });
        VeloUI.toast('Data imported successfully!', 'success');
        setTimeout(() => location.reload(), 1000);
        return true;
      } catch (e) {
        VeloUI.toast('Import failed: Invalid file', 'error');
        return false;
      }
    }
  };

  // Analytics Tracker
  window.VeloAnalytics = {
    track(eventName, properties = {}) {
      if (typeof gtag !== 'undefined') {
        gtag('event', eventName, properties);
      }
      
      // Also store in history
      VeloHistory.push({
        widgetType: 'analytics',
        subtype: eventName,
        meta: properties
      });
    },

    pageView(pageName) {
      this.track('page_view', { page: pageName });
    }
  };

  // Inject required CSS animations
  const style = document.createElement('style');
  style.textContent = `
    @keyframes veloSlideIn {
      from { transform: translateX(400px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    @keyframes veloSlideOut {
      from { transform: translateX(0); opacity: 1; }
      to { transform: translateX(400px); opacity: 0; }
    }
    .velo-spinner {
      width: 50px;
      height: 50px;
      border: 4px solid rgba(0,240,255,0.2);
      border-top: 4px solid #00F0FF;
      border-radius: 50%;
      animation: veloSpin 1s linear infinite;
    }
    @keyframes veloSpin {
      to { transform: rotate(360deg); }
    }
  `;
  document.head.appendChild(style);

  // Auto-save all form inputs on change
  document.addEventListener('DOMContentLoaded', () => {
    // Auto-track page views
    const pageName = document.title || window.location.pathname;
    VeloAnalytics.pageView(pageName);

    // Add auto-save listeners to forms with data-auto-save attribute
    document.querySelectorAll('[data-auto-save]').forEach(form => {
      const key = form.dataset.autoSave;
      form.addEventListener('input', (e) => {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        VeloStorage.autoSave(key, data);
      });
    });
  });

  console.log('✅ Velo Common Library loaded');
})();
