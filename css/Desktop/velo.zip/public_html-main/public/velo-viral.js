/**
 * Velo Viral Growth System
 * Social sharing, referrals, and engagement features
 */
(function() {
  'use strict';

  // Social Share Configuration
  const VeloShare = {
    getPageData() {
      const title = document.title || 'Velo LifeXtreme - Premium Productivity Dashboard';
      const description = document.querySelector('meta[name="description"]')?.content || 
        'Boost your productivity with Velo LifeXtreme - Study tools, fitness trackers, wellness features & more!';
      const url = window.location.href;
      return { title, description, url };
    },

    shareOnTwitter() {
      const { title, url } = this.getPageData();
      const text = `🚀 Check out ${title}! Amazing productivity tools! ✨`;
      window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
      VeloAnalytics?.track('share', { platform: 'twitter' });
    },

    shareOnFacebook() {
      const { url } = this.getPageData();
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
      VeloAnalytics?.track('share', { platform: 'facebook' });
    },

    shareOnLinkedIn() {
      const { url, title } = this.getPageData();
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
      VeloAnalytics?.track('share', { platform: 'linkedin' });
    },

    shareOnWhatsApp() {
      const { title, url } = this.getPageData();
      const text = `🔥 ${title} - ${url}`;
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
      VeloAnalytics?.track('share', { platform: 'whatsapp' });
    },

    shareOnReddit() {
      const { title, url } = this.getPageData();
      window.open(`https://reddit.com/submit?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`, '_blank');
      VeloAnalytics?.track('share', { platform: 'reddit' });
    },

    copyLink() {
      const { url } = this.getPageData();
      navigator.clipboard.writeText(url).then(() => {
        VeloUI?.showToast('Link copied to clipboard! 🎉', 'success');
        VeloAnalytics?.track('share', { platform: 'copy_link' });
      });
    },

    nativeShare() {
      const { title, text, url } = this.getPageData();
      if (navigator.share) {
        navigator.share({ title, text, url })
          .then(() => VeloAnalytics?.track('share', { platform: 'native' }))
          .catch(() => {});
      } else {
        this.copyLink();
      }
    }
  };

  // Floating Share Button
  function createShareButton() {
    if (document.getElementById('velo-share-fab')) return;

    const fab = document.createElement('div');
    fab.id = 'velo-share-fab';
    fab.innerHTML = `
      <style>
        #velo-share-fab {
          position: fixed;
          bottom: 20px;
          right: 20px;
          z-index: 9999;
        }
        .velo-share-btn {
          width: 56px;
          height: 56px;
          border-radius: 50%;
          background: linear-gradient(135deg, #00b0ff, #00eeff);
          border: none;
          cursor: pointer;
          box-shadow: 0 4px 20px rgba(0, 176, 255, 0.4);
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s;
          animation: velo-pulse 2s infinite;
        }
        .velo-share-btn:hover {
          transform: scale(1.1);
          box-shadow: 0 6px 30px rgba(0, 238, 255, 0.6);
        }
        .velo-share-btn svg {
          width: 24px;
          height: 24px;
          fill: #071028;
        }
        .velo-share-menu {
          position: absolute;
          bottom: 70px;
          right: 0;
          background: rgba(7, 16, 40, 0.95);
          border: 1px solid rgba(0, 176, 255, 0.3);
          border-radius: 12px;
          padding: 12px;
          display: none;
          flex-direction: column;
          gap: 8px;
          backdrop-filter: blur(10px);
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
          min-width: 200px;
        }
        .velo-share-menu.active {
          display: flex;
          animation: velo-slideUp 0.3s;
        }
        .velo-share-option {
          padding: 12px 16px;
          background: rgba(0, 176, 255, 0.1);
          border: 1px solid rgba(0, 176, 255, 0.2);
          border-radius: 8px;
          color: #00eeff;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 14px;
        }
        .velo-share-option:hover {
          background: rgba(0, 176, 255, 0.2);
          border-color: #00eeff;
          transform: translateX(-4px);
        }
        @keyframes velo-pulse {
          0%, 100% { box-shadow: 0 4px 20px rgba(0, 176, 255, 0.4); }
          50% { box-shadow: 0 4px 30px rgba(0, 238, 255, 0.6); }
        }
        @keyframes velo-slideUp {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      </style>
      <button class="velo-share-btn" title="Share this page">
        <svg viewBox="0 0 24 24">
          <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/>
        </svg>
      </button>
      <div class="velo-share-menu">
        <div class="velo-share-option" data-platform="twitter">
          <span>🐦</span> Share on Twitter
        </div>
        <div class="velo-share-option" data-platform="facebook">
          <span>📘</span> Share on Facebook
        </div>
        <div class="velo-share-option" data-platform="linkedin">
          <span>💼</span> Share on LinkedIn
        </div>
        <div class="velo-share-option" data-platform="whatsapp">
          <span>💬</span> Share on WhatsApp
        </div>
        <div class="velo-share-option" data-platform="reddit">
          <span>🤖</span> Share on Reddit
        </div>
        <div class="velo-share-option" data-platform="copy">
          <span>🔗</span> Copy Link
        </div>
      </div>
    `;

    document.body.appendChild(fab);

    const btn = fab.querySelector('.velo-share-btn');
    const menu = fab.querySelector('.velo-share-menu');

    btn.addEventListener('click', () => {
      menu.classList.toggle('active');
    });

    document.addEventListener('click', (e) => {
      if (!fab.contains(e.target)) {
        menu.classList.remove('active');
      }
    });

    fab.querySelectorAll('.velo-share-option').forEach(option => {
      option.addEventListener('click', () => {
        const platform = option.dataset.platform;
        menu.classList.remove('active');
        
        switch(platform) {
          case 'twitter': VeloShare.shareOnTwitter(); break;
          case 'facebook': VeloShare.shareOnFacebook(); break;
          case 'linkedin': VeloShare.shareOnLinkedIn(); break;
          case 'whatsapp': VeloShare.shareOnWhatsApp(); break;
          case 'reddit': VeloShare.shareOnReddit(); break;
          case 'copy': VeloShare.copyLink(); break;
        }
      });
    });
  }

  // Engagement Tracking
  function trackEngagement() {
    let startTime = Date.now();
    let maxScroll = 0;

    window.addEventListener('scroll', () => {
      const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      maxScroll = Math.max(maxScroll, scrollPercent);
    });

    window.addEventListener('beforeunload', () => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      VeloAnalytics?.track('engagement', {
        timeSpent,
        maxScroll: Math.round(maxScroll),
        page: window.location.pathname
      });
    });
  }

  // Referral System
  function initReferralSystem() {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    
    if (ref) {
      localStorage.setItem('velo_referrer', ref);
      VeloAnalytics?.track('referral_visit', { referrer: ref });
    }

    // Generate unique referral code
    if (!localStorage.getItem('velo_ref_code')) {
      const code = 'VELO' + Math.random().toString(36).substr(2, 6).toUpperCase();
      localStorage.setItem('velo_ref_code', code);
    }
  }

  // Install Prompt for PWA
  let deferredPrompt;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    // Show install banner after 30 seconds
    setTimeout(() => {
      if (deferredPrompt && !localStorage.getItem('velo_pwa_dismissed')) {
        showInstallPrompt();
      }
    }, 30000);
  });

  function showInstallPrompt() {
    const banner = document.createElement('div');
    banner.innerHTML = `
      <style>
        .velo-install-banner {
          position: fixed;
          bottom: 80px;
          left: 50%;
          transform: translateX(-50%);
          background: linear-gradient(135deg, rgba(0, 176, 255, 0.95), rgba(0, 238, 255, 0.95));
          padding: 16px 24px;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0, 176, 255, 0.4);
          z-index: 9998;
          display: flex;
          align-items: center;
          gap: 16px;
          max-width: 90%;
          animation: velo-slideUp 0.3s;
        }
        .velo-install-banner button {
          padding: 8px 16px;
          border-radius: 6px;
          border: none;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.2s;
        }
        .velo-install-yes {
          background: #071028;
          color: #00eeff;
        }
        .velo-install-yes:hover {
          transform: scale(1.05);
        }
        .velo-install-no {
          background: transparent;
          color: #071028;
        }
      </style>
      <div class="velo-install-banner">
        <span style="color: #071028; font-weight: bold;">📱 Install Velo for quick access!</span>
        <button class="velo-install-yes">Install</button>
        <button class="velo-install-no">Later</button>
      </div>
    `;
    document.body.appendChild(banner);

    banner.querySelector('.velo-install-yes').addEventListener('click', async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        VeloAnalytics?.track('pwa_install', { outcome });
        deferredPrompt = null;
      }
      banner.remove();
    });

    banner.querySelector('.velo-install-no').addEventListener('click', () => {
      localStorage.setItem('velo_pwa_dismissed', 'true');
      banner.remove();
    });
  }

  // Initialize on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      createShareButton();
      trackEngagement();
      initReferralSystem();
    });
  } else {
    createShareButton();
    trackEngagement();
    initReferralSystem();
  }

  // Expose to global scope
  window.VeloShare = VeloShare;
})();
