/**
 * Velo Global Initialization Script
 * Load all essential scripts for SEO, Analytics, Ads, and Viral Features
 * Add this script to ALL pages for consistent functionality
 */
(function() {
  'use strict';

  // List of scripts to load
  const scripts = [
    { src: '/seo-meta.js', async: false },
    { src: '/velo-viral.js', async: true },
    { src: '/velo-seo-boost.js', async: true },
    { src: '/velo-ad.js', async: true },
    { src: '/velo-banner-ad.js', async: true },
    { src: '/velo-common.js', async: true }
  ];

  // Google Analytics
  const gaScript1 = document.createElement('script');
  gaScript1.async = true;
  gaScript1.src = 'https://www.googletagmanager.com/gtag/js?id=G-5HYFF0F9X6';
  document.head.appendChild(gaScript1);

  const gaScript2 = document.createElement('script');
  gaScript2.textContent = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-5HYFF0F9X6', {
      page_path: window.location.pathname,
      page_title: document.title
    });
  `;
  document.head.appendChild(gaScript2);

  // Load all Velo scripts
  scripts.forEach(scriptConfig => {
    const script = document.createElement('script');
    script.src = scriptConfig.src;
    if (scriptConfig.async) {
      script.async = true;
    }
    script.onerror = () => console.warn(`Failed to load: ${scriptConfig.src}`);
    document.head.appendChild(script);
  });

  // Add PWA manifest if not present
  if (!document.querySelector('link[rel="manifest"]')) {
    const manifest = document.createElement('link');
    manifest.rel = 'manifest';
    manifest.href = '/manifest.json';
    document.head.appendChild(manifest);
  }

  // Add favicon if not present
  if (!document.querySelector('link[rel="icon"]')) {
    const favicon = document.createElement('link');
    favicon.rel = 'icon';
    favicon.href = '/favicon.ico';
    document.head.appendChild(favicon);
  }

  // Register Service Worker for offline functionality
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js')
        .then(reg => console.log('✅ Service Worker registered'))
        .catch(err => console.warn('Service Worker registration failed:', err));
    });
  }

  // Performance tracking
  window.addEventListener('load', () => {
    if (window.performance && window.performance.timing) {
      const perf = window.performance.timing;
      const loadTime = perf.loadEventEnd - perf.navigationStart;
      
      if (window.gtag) {
        gtag('event', 'page_performance', {
          value: loadTime,
          page_path: window.location.pathname
        });
      }
    }
  });

  console.log('🚀 Velo Global Init: All systems loaded!');
})();
