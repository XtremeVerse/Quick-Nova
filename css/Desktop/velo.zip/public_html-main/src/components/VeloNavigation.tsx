import { useState, useEffect } from 'react';
import { HamburgerMenuIcon, Cross1Icon } from '@radix-ui/react-icons';

const VeloNavigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLogoGlowing, setIsLogoGlowing] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  // Auto glow animation for logo
  useEffect(() => {
    const interval = setInterval(() => {
      setIsLogoGlowing(true);
      setTimeout(() => setIsLogoGlowing(false), 3000);
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  // Scroll spy to highlight active section
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'dashboard', 'about', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;
          
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { path: 'home', label: 'Home' },
    { path: 'dashboard', label: 'Dashboard' },
    { path: 'about', label: 'About' },
    { path: 'contact', label: 'Contact' }
  ];

  const handleNavClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const isActive = (path: string) => activeSection === path;

  return (
    <header className="fixed top-0 left-0 w-full z-50 px-4 md:px-24 py-5">
      <div className="velo-glass rounded-2xl flex justify-between items-center px-6 py-4">
        {/* Logo */}
        <button 
          onClick={() => handleNavClick('home')}
          className={`text-3xl font-bold velo-neon-text transition-all duration-700 ${
            isLogoGlowing ? 'velo-neon-active' : ''
          }`}
          style={{
            animation: isLogoGlowing ? 'veloGlow 3s ease-in-out' : 'none'
          }}
        >
          Velo
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex gap-8">
          {navLinks.map((link) => (
            <button
              key={link.path}
              onClick={() => handleNavClick(link.path)}
              className={`text-lg font-medium px-5 py-2 border-2 border-transparent rounded-lg transition-all duration-300 ${
                isActive(link.path)
                  ? 'border-primary text-primary'
                  : 'text-foreground hover:border-primary hover:text-primary'
              }`}
              style={{
                boxShadow: isActive(link.path) ? 'var(--neon-glow)' : 'none'
              }}
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Mobile Menu Icon */}
        <button
          className="md:hidden text-foreground text-3xl transition-transform duration-300"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          style={{ transform: isMenuOpen ? 'rotate(180deg)' : 'none' }}
        >
          {isMenuOpen ? <Cross1Icon className="w-8 h-8" /> : <HamburgerMenuIcon className="w-8 h-8" />}
        </button>

        {/* Mobile Navigation */}
        <nav
          className={`absolute top-full left-0 w-full mt-2 md:hidden transition-all duration-400 ease-in-out ${
            isMenuOpen 
              ? 'opacity-100 max-h-96 visible' 
              : 'opacity-0 max-h-0 invisible'
          }`}
        >
          <div className="velo-glass rounded-2xl mx-4 p-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <button
                key={link.path}
                onClick={() => handleNavClick(link.path)}
                className={`text-lg font-medium px-5 py-3 border-2 border-transparent rounded-lg transition-all duration-300 text-center ${
                  isActive(link.path)
                    ? 'border-primary text-primary'
                    : 'text-foreground hover:border-primary hover:text-primary'
                }`}
                style={{
                  boxShadow: isActive(link.path) ? 'var(--neon-glow)' : 'none'
                }}
              >
                {link.label}
              </button>
            ))}
          </div>
        </nav>
      </div>

      {/* Keyframe animation for logo glow */}
      <style>{`
        @keyframes veloGlow {
          0% {
            background-position: -600px 0;
            text-shadow: none;
          }
          40%, 70% {
            background-position: 0 0;
            text-shadow: var(--neon-glow);
          }
          100% {
            background-position: -600px 0;
            text-shadow: none;
          }
        }
      `}</style>
    </header>
  );
};

export default VeloNavigation;