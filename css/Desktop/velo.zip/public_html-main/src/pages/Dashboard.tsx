import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  Clock, 
  CheckSquare, 
  Plus, 
  Play, 
  Pause, 
  RotateCcw,
  Droplets,
  StickyNote,
  Settings
} from 'lucide-react';

interface Widget {
  id: string;
  type: 'pomodoro' | 'tasks' | 'water' | 'notes';
  title: string;
}

interface Task {
  id: string;
  text: string;
  completed: boolean;
}

const Dashboard = () => {
  const [widgets, setWidgets] = useState<Widget[]>([
    { id: '1', type: 'pomodoro', title: 'Pomodoro Timer' },
    { id: '2', type: 'tasks', title: 'Tasks' },
    { id: '3', type: 'water', title: 'Water Tracker' }
  ]);

  // Pomodoro state
  const [pomodoroTime, setPomodoroTime] = useState(25 * 60); // 25 minutes in seconds
  const [isRunning, setIsRunning] = useState(false);
  const [isBreak, setIsBreak] = useState(false);

  // Tasks state
  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', text: 'Complete project documentation', completed: false },
    { id: '2', text: 'Review code changes', completed: true },
    { id: '3', text: 'Plan tomorrow\'s tasks', completed: false }
  ]);
  const [newTask, setNewTask] = useState('');

  // Water tracker state
  const [waterCups, setWaterCups] = useState(0);
  const [notes, setNotes] = useState('Welcome to your Velo dashboard! 🚀\n\nThis is your personal workspace where you can:\n- Track your productivity with Pomodoro timers\n- Manage your daily tasks\n- Monitor your hydration\n- Take quick notes\n\nCustomize your widgets and make this space truly yours!');

  // Pomodoro timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && pomodoroTime > 0) {
      interval = setInterval(() => {
        setPomodoroTime(time => time - 1);
      }, 1000);
    } else if (pomodoroTime === 0) {
      setIsRunning(false);
      setIsBreak(!isBreak);
      setPomodoroTime(isBreak ? 25 * 60 : 5 * 60); // Switch between work and break
    }
    return () => clearInterval(interval);
  }, [isRunning, pomodoroTime, isBreak]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePomodoro = () => setIsRunning(!isRunning);
  const resetPomodoro = () => {
    setIsRunning(false);
    setPomodoroTime(25 * 60);
    setIsBreak(false);
  };

  const addTask = () => {
    if (newTask.trim()) {
      setTasks([...tasks, { id: Date.now().toString(), text: newTask, completed: false }]);
      setNewTask('');
    }
  };

  const toggleTask = (taskId: string) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, completed: !task.completed } : task
    ));
  };

  const addWidget = (type: Widget['type']) => {
    const titles = {
      pomodoro: 'Pomodoro Timer',
      tasks: 'Tasks',
      water: 'Water Tracker',
      notes: 'Quick Notes'
    };
    
    setWidgets([...widgets, {
      id: Date.now().toString(),
      type,
      title: titles[type]
    }]);
  };

  const renderWidget = (widget: Widget) => {
    switch (widget.type) {
      case 'pomodoro':
        return (
          <Card key={widget.id} className="velo-glass border-border/20">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="w-5 h-5 text-primary" />
                {widget.title}
              </CardTitle>
              <Badge variant={isBreak ? "secondary" : "default"}>
                {isBreak ? 'Break' : 'Focus'}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-5xl font-bold text-primary mb-4 font-mono">
                  {formatTime(pomodoroTime)}
                </div>
                <div className="flex gap-2 justify-center">
                  <Button
                    onClick={togglePomodoro}
                    variant="default"
                    size="sm"
                    className="velo-btn-neon"
                  >
                    {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  <Button
                    onClick={resetPomodoro}
                    variant="outline"
                    size="sm"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'tasks':
        return (
          <Card key={widget.id} className="velo-glass border-border/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckSquare className="w-5 h-5 text-primary" />
                {widget.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {tasks.map(task => (
                  <div key={task.id} className="flex items-center gap-3 p-2 rounded-lg bg-card/30">
                    <button
                      onClick={() => toggleTask(task.id)}
                      className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                        task.completed 
                          ? 'bg-primary border-primary text-primary-foreground' 
                          : 'border-border'
                      }`}
                    >
                      {task.completed && <CheckSquare className="w-3 h-3" />}
                    </button>
                    <span className={task.completed ? 'line-through text-muted-foreground' : ''}>
                      {task.text}
                    </span>
                  </div>
                ))}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newTask}
                    onChange={(e) => setNewTask(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addTask()}
                    placeholder="Add new task..."
                    className="flex-1 px-3 py-2 bg-background/50 border border-border rounded-lg text-sm"
                  />
                  <Button onClick={addTask} size="sm" variant="outline">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'water':
        return (
          <Card key={widget.id} className="velo-glass border-border/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Droplets className="w-5 h-5 text-primary" />
                {widget.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-2xl font-bold mb-4">
                  {waterCups} / 8 cups
                </div>
                <Progress value={(waterCups / 8) * 100} className="mb-4" />
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 8 }, (_, i) => (
                    <button
                      key={i}
                      onClick={() => setWaterCups(i + 1)}
                      className={`aspect-square rounded-lg border-2 flex items-center justify-center transition-all ${
                        i < waterCups
                          ? 'bg-primary/20 border-primary text-primary'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <Droplets className="w-4 h-4" />
                    </button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'notes':
        return (
          <Card key={widget.id} className="velo-glass border-border/20 col-span-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <StickyNote className="w-5 h-5 text-primary" />
                {widget.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Your thoughts, ideas, reminders..."
                className="min-h-32 bg-background/30 border-border/20"
              />
            </CardContent>
          </Card>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-primary mb-2">Dashboard</h1>
            <p className="text-muted-foreground">Your personal productivity workspace</p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => addWidget('pomodoro')}
              variant="outline"
              size="sm"
            >
              <Clock className="w-4 h-4 mr-2" />
              Add Timer
            </Button>
            <Button
              onClick={() => addWidget('tasks')}
              variant="outline"
              size="sm"
            >
              <CheckSquare className="w-4 h-4 mr-2" />
              Add Tasks
            </Button>
            <Button
              onClick={() => addWidget('notes')}
              variant="outline"
              size="sm"
            >
              <StickyNote className="w-4 h-4 mr-2" />
              Add Notes
            </Button>
          </div>
        </div>

        {/* Widgets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {widgets.map(renderWidget)}
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <div className="velo-glass rounded-2xl p-6 inline-block">
            <p className="text-muted-foreground mb-4">
              Customize your dashboard by adding widgets and organizing your workflow
            </p>
            <a href="create.html" target="_blank">
              <Button className="velo-btn-neon">
                <Settings className="w-4 h-4 mr-2" />
                For More Features Click Me
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;