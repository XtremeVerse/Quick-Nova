import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import AnimatedBackground from '@/components/AnimatedBackground';

const Home = () => {
  const [isGlowing, setIsGlowing] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const title = document.getElementById('hero-title');
      if (title) {
        title.style.backgroundImage = `radial-gradient(circle at ${e.clientX}px ${e.clientY}px, rgba(0,238,255,0.8), transparent 70%)`;
        setIsGlowing(true);
        setTimeout(() => setIsGlowing(false), 1200);
      }
    };

    const handleTouch = (e: TouchEvent) => {
      if (e.touches[0]) {
        const touch = e.touches[0];
        const title = document.getElementById('hero-title');
        if (title) {
          title.style.backgroundImage = `radial-gradient(circle at ${touch.clientX}px ${touch.clientY}px, rgba(0,238,255,0.8), transparent 70%)`;
          setIsGlowing(true);
          setTimeout(() => setIsGlowing(false), 1200);
        }
      }
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('touchmove', handleTouch);
    document.addEventListener('click', (e) => handleMouseMove(e as any));

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('touchmove', handleTouch);
      document.removeEventListener('click', handleMouseMove);
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col justify-center items-center text-center relative overflow-hidden">
      <AnimatedBackground />
      
      <main className="z-10 px-4">
        <h1 
          id="hero-title"
          className={`text-6xl md:text-8xl font-bold velo-neon-text mb-6 select-none transition-all duration-1200 ${
            isGlowing ? 'velo-neon-active' : ''
          }`}
        >
          <span className="inline-block transition-transform duration-300 hover:scale-110 hover:drop-shadow-[0_0_25px_#00eeff]">
            Welcome
          </span>{' '}
          <span className="inline-block transition-transform duration-300 hover:scale-110 hover:drop-shadow-[0_0_25px_#00eeff]">
            to
          </span>{' '}
          <span className="inline-block transition-transform duration-300 hover:scale-110 hover:drop-shadow-[0_0_25px_#00eeff]">
            Velo
          </span>
        </h1>

        <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mb-12 leading-relaxed">
          The future of smooth, glowing interaction. Experience neon vibes with elegance and productivity tools designed for the modern digital age.
        </p>

        <a
          href="start.html"
          className="group relative inline-block text-xl font-semibold text-foreground/70 bg-card px-12 py-4 rounded-lg border-2 border-transparent overflow-hidden transition-all duration-500 hover:text-primary hover:tracking-wider"
          style={{
            textShadow: 'none'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.textShadow = 'var(--neon-glow)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.textShadow = 'none';
          }}
        >
          {/* Animated border spans */}
          <span className="absolute top-0 left-0 w-1/2 h-0.5 bg-primary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></span>
          <span className="absolute top-0 right-0 w-1/2 h-0.5 bg-primary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-right"></span>
          <span className="absolute bottom-0 left-0 w-1/2 h-0.5 bg-primary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></span>
          <span className="absolute bottom-0 right-0 w-1/2 h-0.5 bg-primary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-right"></span>
          <span className="absolute left-0 top-0 w-0.5 h-1/2 bg-primary transform scale-y-0 group-hover:scale-y-100 transition-transform duration-500 origin-top"></span>
          <span className="absolute left-0 bottom-0 w-0.5 h-1/2 bg-primary transform scale-y-0 group-hover:scale-y-100 transition-transform duration-500 origin-bottom"></span>
          <span className="absolute right-0 top-0 w-0.5 h-1/2 bg-primary transform scale-y-0 group-hover:scale-y-100 transition-transform duration-500 origin-top"></span>
          <span className="absolute right-0 bottom-0 w-0.5 h-1/2 bg-primary transform scale-y-0 group-hover:scale-y-100 transition-transform duration-500 origin-bottom"></span>
          
          Let's Start
        </a>
      </main>
    </div>
  );
};

export default Home;