import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Rocket, 
  Book, 
  Dumbbell, 
  Calendar, 
  Crown, 
  HelpCircle,
  Zap,
  Target,
  Brain,
  Shield
} from 'lucide-react';

interface Checkpoint {
  id: number;
  icon: any;
  active: boolean;
  glowing: boolean;
}

const About = () => {
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>([
    { id: 0, icon: Rocket, active: false, glowing: false },
    { id: 1, icon: Book, active: false, glowing: false },
    { id: 2, icon: Dumbbell, active: false, glowing: false },
    { id: 3, icon: Calendar, active: false, glowing: false },
    { id: 4, icon: Crown, active: false, glowing: false },
    { id: 5, icon: HelpCircle, active: false, glowing: false }
  ]);

  const [visibleSections, setVisibleSections] = useState<Set<number>>(new Set());
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const sectionIndex = parseInt(entry.target.getAttribute('data-section') || '0');
          
          if (entry.isIntersecting) {
            setVisibleSections(prev => new Set([...prev, sectionIndex]));
            setCheckpoints(prev => prev.map(cp => 
              cp.id === sectionIndex ? { ...cp, active: true } : cp
            ));
          }
        });
      },
      { threshold: 0.3 }
    );

    document.querySelectorAll('.about-section').forEach(section => {
      observer.observe(section);
    });

    return () => observer.disconnect();
  }, []);

  const handlePointerEffect = (e: React.MouseEvent) => {
    const { clientX, clientY } = e;
    
    checkpoints.forEach((_, index) => {
      const checkpoint = document.getElementById(`checkpoint-${index}`);
      if (checkpoint) {
        const rect = checkpoint.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const distance = Math.hypot(clientX - centerX, clientY - centerY);
        
        if (distance < 110) {
          setCheckpoints(prev => prev.map(cp => 
            cp.id === index ? { ...cp, glowing: true } : cp
          ));
          
          setTimeout(() => {
            setCheckpoints(prev => prev.map(cp => 
              cp.id === index ? { ...cp, glowing: false } : cp
            ));
          }, 900);
        }
      }
    });
  };

  const features = [
    {
      icon: Target,
      title: "Custom Dashboard",
      description: "Create a workspace by dragging widgets: timers, lists, charts, and more."
    },
    {
      icon: Zap,
      title: "Pomodoro & Timers",
      description: "Flexible work/break intervals, sound cues, and local notifications."
    },
    {
      icon: Shield,
      title: "Profile-Free Mode",
      description: "All data stored in your browser by default. Optional future sync/login."
    }
  ];

  const studyTools = [
    {
      icon: Target,
      title: "Exam Countdown",
      description: "Countdowns with auto reminders and calendar exports."
    },
    {
      icon: Book,
      title: "Task Manager",
      description: "Subject/topic categorization, priority, deadlines and filters."
    },
    {
      icon: Brain,
      title: "Progress Tracker",
      description: "Visualize hours studied, topic completion and streaks."
    }
  ];

  const faqItems = [
    {
      question: "Do I need an account?",
      answer: "No — core features are available without creating an account. Data is saved in your browser's storage. You can opt-in to sync later."
    },
    {
      question: "Is Velo free?",
      answer: "Yes. Core tools (timers, trackers, planners) are free. Premium AI tools and sync are optional paid upgrades in future releases."
    },
    {
      question: "Does it work offline?",
      answer: "Basic features work offline in the browser. Advanced sync and cloud features require connectivity (planned PWA support)."
    },
    {
      question: "Can I export my data?",
      answer: "You can export tasks, timers and resource lists as JSON or CSV for backup or transfer (planned feature)."
    }
  ];

  return (
    <div 
      className="min-h-screen pt-24 pb-12"
      onMouseMove={handlePointerEffect}
    >
      <div className="max-w-6xl mx-auto px-4 relative">
        {/* Timeline */}
        <div className="relative pl-20 md:pl-32">
          {/* Neon bar */}
          <div 
            className="absolute left-8 md:left-16 top-4 bottom-4 w-2 rounded-full bg-gradient-to-b from-primary/40 to-secondary/20"
            style={{ 
              boxShadow: '0 0 30px rgba(0,238,255,0.1)',
              filter: 'drop-shadow(0 0 20px rgba(0,238,255,0.05))'
            }}
          />

          {/* Section 1: Mission & Vision */}
          <section 
            className={`about-section mb-16 transition-all duration-700 ${
              visibleSections.has(0) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-9'
            }`}
            data-section="0"
          >
            <div 
              id="checkpoint-0"
              className={`absolute -left-16 md:-left-12 w-12 h-12 rounded-xl velo-glass flex items-center justify-center border-2 transition-all duration-300 ${
                checkpoints[0].active ? 'border-primary text-primary' : 'border-border text-muted-foreground'
              } ${checkpoints[0].glowing ? 'border-secondary text-secondary scale-110' : ''}`}
              style={{
                boxShadow: checkpoints[0].active ? 'var(--neon-glow)' : checkpoints[0].glowing ? 'var(--purple-glow)' : 'none'
              }}
            >
              <Rocket className="w-6 h-6" />
            </div>
            
            <Card className="velo-glass border-border/20">
              <CardHeader>
                <CardTitle className="text-2xl text-primary flex items-center gap-3">
                  Velo — Mission & Vision
                </CardTitle>
                <p className="text-muted-foreground">
                  Velo combines elegant design with practical productivity tools — all local-first. 
                  No signup required to start using core features. Built for students, creators, and life optimizers.
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {features.map((feature, index) => (
                    <Card key={index} className="velo-glass border-border/10 hover:border-primary/20 transition-all duration-300 hover:-translate-y-1">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                            <feature.icon className="w-6 h-6" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold mb-2">{feature.title}</h4>
                            <p className="text-sm text-muted-foreground">{feature.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Section 2: Study Tools */}
          <section 
            className={`about-section mb-16 transition-all duration-700 ${
              visibleSections.has(1) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-9'
            }`}
            data-section="1"
          >
            <div 
              id="checkpoint-1"
              className={`absolute -left-16 md:-left-12 w-12 h-12 rounded-xl velo-glass flex items-center justify-center border-2 transition-all duration-300 ${
                checkpoints[1].active ? 'border-primary text-primary' : 'border-border text-muted-foreground'
              } ${checkpoints[1].glowing ? 'border-secondary text-secondary scale-110' : ''}`}
            >
              <Book className="w-6 h-6" />
            </div>
            
            <Card className="velo-glass border-border/20">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">Study Tools</CardTitle>
                <p className="text-muted-foreground">
                  Everything a student needs to plan study sessions, track progress, store resources and prepare for exams.
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  {studyTools.map((tool, index) => (
                    <Card key={index} className="velo-glass border-border/10 hover:border-primary/20 transition-all duration-300 hover:-translate-y-1">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                            <tool.icon className="w-6 h-6" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold mb-2">{tool.title}</h4>
                            <p className="text-sm text-muted-foreground">{tool.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="velo-glass rounded-lg p-4 border border-border/10">
                    <div className="font-semibold mb-2">Study Setup</div>
                    <Progress value={85} className="mb-2" />
                    <div className="text-sm text-muted-foreground">85% of core study widgets ready</div>
                  </div>
                  <div className="velo-glass rounded-lg p-4 border border-border/10">
                    <div className="font-semibold mb-2">Notes & Resources</div>
                    <Progress value={72} className="mb-2" />
                    <div className="text-sm text-muted-foreground">72% of resources organized</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Section 3: FAQ */}
          <section 
            className={`about-section mb-16 transition-all duration-700 ${
              visibleSections.has(2) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-9'
            }`}
            data-section="2"
          >
            <div 
              id="checkpoint-2"
              className={`absolute -left-16 md:-left-12 w-12 h-12 rounded-xl velo-glass flex items-center justify-center border-2 transition-all duration-300 ${
                checkpoints[2].active ? 'border-primary text-primary' : 'border-border text-muted-foreground'
              } ${checkpoints[2].glowing ? 'border-secondary text-secondary scale-110' : ''}`}
            >
              <HelpCircle className="w-6 h-6" />
            </div>
            
            <Card className="velo-glass border-border/20">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">Frequently Asked Questions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {faqItems.map((item, index) => (
                    <div 
                      key={index}
                      className={`velo-glass rounded-lg p-4 cursor-pointer transition-all duration-300 border-l-4 ${
                        openFaq === index 
                          ? 'border-l-primary' 
                          : 'border-l-transparent hover:border-l-primary/50'
                      }`}
                      onClick={() => setOpenFaq(openFaq === index ? null : index)}
                      style={{
                        boxShadow: openFaq === index ? '0 8px 30px rgba(0,238,255,0.05)' : 'none'
                      }}
                    >
                      <div className="font-semibold text-foreground">{item.question}</div>
                      {openFaq === index && (
                        <div className="mt-3 text-muted-foreground text-sm">{item.answer}</div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>

          {/* CTA Section */}
          <section className="text-center">
            <Card className="velo-glass border-border/20 inline-block">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary">
                    <Rocket className="w-8 h-8" />
                  </div>
                  <div className="text-left">
                    <div className="text-xl font-bold">Ready to start?</div>
                    <div className="text-muted-foreground">Jump in and customize your first dashboard widget.</div>
                  </div>
                </div>
                <a 
                  href="/dashboard" 
                  className="velo-btn-neon inline-flex items-center gap-2 hover:scale-105 transition-transform duration-300"
                >
                  Open Velo • Start Now
                </a>
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </div>
  );
};

export default About;